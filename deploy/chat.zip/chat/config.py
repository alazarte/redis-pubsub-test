
class Config(object):
    pass
