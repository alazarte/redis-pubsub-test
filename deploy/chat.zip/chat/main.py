from chat import Chat

chat = Chat()
chat.chat()

