class Command(object):

    action              = None
    match               = None
    help                = None
    contains_arguments  = None
